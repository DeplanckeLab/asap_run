#!/usr/bin/env bash
set -eu

Rscript -e "devtools::test()"