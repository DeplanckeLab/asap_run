#!/usr/bin/env bash
set -eu

rm -rf docs
rm -f src/Makevars
rm -rf src/*.so src/*.dll src/*.o src/**/*.o