Tests in this folder are for stringent correctness tests on large, real-world
datasets. They are not meant to run frequently, but do provide a record for
how to verify that results replicate across tools appropriately