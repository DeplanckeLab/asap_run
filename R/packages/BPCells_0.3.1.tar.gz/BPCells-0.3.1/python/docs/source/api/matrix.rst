Matrix functions
-----------------
.. currentmodule:: bpcells

.. autosummary::
    :toctree: ../generated/

    experimental.DirMatrix
    experimental.MemMatrix
