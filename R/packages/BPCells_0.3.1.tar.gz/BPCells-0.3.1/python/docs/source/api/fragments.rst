Fragment functions
-------------------
.. currentmodule:: bpcells

.. autosummary::
    :toctree: ../generated/

    experimental.import_10x_fragments
    experimental.build_cell_groups
    experimental.pseudobulk_insertion_counts
    experimental.precalculate_insertion_counts
    experimental.PrecalculatedInsertionMatrix
