#!/usr/bin/env bash
set -eu

rm -rf docs/build
rm -rf build

rm -f src/bpcells-cpp/**/*.o