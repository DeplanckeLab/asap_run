#!/user/bin/env bash
set -eu

tox run